@echo off
start http://localhost:8000
python3 -m http.server 8000
echo.
echo Server stopped. You can close this window.
pause
